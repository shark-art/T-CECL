from .eval_matrix import eval_score_matrix
from .random_choice import pyx_randint_choice, pyx_batch_randint_choice
from .tools import is_ndarray, float_type, int_type

# from .random_choice import _init_random_seed
# _init_random_seed(2020)
